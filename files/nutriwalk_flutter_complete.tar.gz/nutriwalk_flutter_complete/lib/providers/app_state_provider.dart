import 'package:flutter/foundation.dart';
import '../models/user_profile.dart';
import '../models/meal_log.dart';
import '../models/activity_log.dart';

class AppStateProvider with ChangeNotifier {
  UserProfile? _userProfile;
  List<MealLog> _todayMeals = [];
  ActivityLog? _todayActivity;
  int _selectedBottomNavIndex = 0;

  UserProfile? get userProfile => _userProfile;
  List<MealLog> get todayMeals => _todayMeals;
  ActivityLog? get todayActivity => _todayActivity;
  int get selectedBottomNavIndex => _selectedBottomNavIndex;

  void setUserProfile(UserProfile profile) {
    _userProfile = profile;
    notifyListeners();
  }

  void setTodayMeals(List<MealLog> meals) {
    _todayMeals = meals;
    notifyListeners();
  }

  void addMeal(MealLog meal) {
    _todayMeals.add(meal);
    notifyListeners();
  }

  void setTodayActivity(ActivityLog activity) {
    _todayActivity = activity;
    notifyListeners();
  }

  void setBottomNavIndex(int index) {
    _selectedBottomNavIndex = index;
    notifyListeners();
  }

  int get totalCaloriesToday {
    return _todayMeals.fold(0, (sum, meal) => sum + meal.totalCalories);
  }

  int get stepsToday => _todayActivity?.steps ?? 0;

  double get calorieProgress {
    if (_userProfile == null) return 0.0;
    return totalCaloriesToday / _userProfile!.dailyCalorieGoal;
  }

  double get stepProgress {
    if (_userProfile == null) return 0.0;
    return stepsToday / _userProfile!.dailyStepGoal;
  }
}

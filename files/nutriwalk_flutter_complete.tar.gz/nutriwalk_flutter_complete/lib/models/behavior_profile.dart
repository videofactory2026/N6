class BehaviorProfile {
  final String userId;
  final int nudgesSent;
  final int nudgesOpened;
  final int nudgesIgnored;
  final String currentNudgeTone; // 'encouraging', 'neutral', 'stern'
  final List<DailyStepData> stepHistory;
  final int currentAdaptiveStepGoal;
  final DateTime lastNudgeSent;
  final DateTime createdAt;
  final DateTime updatedAt;

  BehaviorProfile({
    required this.userId,
    this.nudgesSent = 0,
    this.nudgesOpened = 0,
    this.nudgesIgnored = 0,
    this.currentNudgeTone = 'encouraging',
    required this.stepHistory,
    required this.currentAdaptiveStepGoal,
    required this.lastNudgeSent,
    required this.createdAt,
    required this.updatedAt,
  });

  // Calculate nudge ignore rate
  double get nudgeIgnoreRate {
    if (nudgesSent == 0) return 0.0;
    return nudgesIgnored / nudgesSent;
  }

  // Calculate nudge open rate
  double get nudgeOpenRate {
    if (nudgesSent == 0) return 0.0;
    return nudgesOpened / nudgesSent;
  }

  // Get average steps from last 7 days
  int get averageStepsLast7Days {
    if (stepHistory.isEmpty) return 0;
    
    final last7Days = stepHistory
        .where((data) => 
            DateTime.now().difference(data.date).inDays < 7)
        .toList();
    
    if (last7Days.isEmpty) return 0;
    
    final totalSteps = last7Days.fold<int>(
      0, 
      (sum, data) => sum + data.steps,
    );
    
    return (totalSteps / last7Days.length).round();
  }

  // Check if nudge tone should be adapted
  bool get shouldAdaptNudgeTone {
    // If ignore rate is > 70% and we sent at least 5 nudges
    return nudgesSent >= 5 && nudgeIgnoreRate > 0.7;
  }

  // Get next nudge tone
  String get nextNudgeTone {
    if (!shouldAdaptNudgeTone) return currentNudgeTone;
    
    switch (currentNudgeTone) {
      case 'encouraging':
        return 'neutral';
      case 'neutral':
        return 'stern';
      case 'stern':
      default:
        return 'encouraging'; // Cycle back
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'nudges_sent': nudgesSent,
      'nudges_opened': nudgesOpened,
      'nudges_ignored': nudgesIgnored,
      'current_nudge_tone': currentNudgeTone,
      'step_history': stepHistory.map((d) => d.toJson()).toList(),
      'current_adaptive_step_goal': currentAdaptiveStepGoal,
      'last_nudge_sent': lastNudgeSent.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory BehaviorProfile.fromJson(Map<String, dynamic> json) {
    return BehaviorProfile(
      userId: json['user_id'] as String,
      nudgesSent: json['nudges_sent'] as int? ?? 0,
      nudgesOpened: json['nudges_opened'] as int? ?? 0,
      nudgesIgnored: json['nudges_ignored'] as int? ?? 0,
      currentNudgeTone: json['current_nudge_tone'] as String? ?? 'encouraging',
      stepHistory: (json['step_history'] as List?)
          ?.map((d) => DailyStepData.fromJson(d as Map<String, dynamic>))
          .toList() ?? [],
      currentAdaptiveStepGoal: json['current_adaptive_step_goal'] as int,
      lastNudgeSent: DateTime.parse(json['last_nudge_sent'] as String),
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  BehaviorProfile copyWith({
    String? userId,
    int? nudgesSent,
    int? nudgesOpened,
    int? nudgesIgnored,
    String? currentNudgeTone,
    List<DailyStepData>? stepHistory,
    int? currentAdaptiveStepGoal,
    DateTime? lastNudgeSent,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return BehaviorProfile(
      userId: userId ?? this.userId,
      nudgesSent: nudgesSent ?? this.nudgesSent,
      nudgesOpened: nudgesOpened ?? this.nudgesOpened,
      nudgesIgnored: nudgesIgnored ?? this.nudgesIgnored,
      currentNudgeTone: currentNudgeTone ?? this.currentNudgeTone,
      stepHistory: stepHistory ?? this.stepHistory,
      currentAdaptiveStepGoal: currentAdaptiveStepGoal ?? this.currentAdaptiveStepGoal,
      lastNudgeSent: lastNudgeSent ?? this.lastNudgeSent,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class DailyStepData {
  final DateTime date;
  final int steps;
  final bool goalMet;

  DailyStepData({
    required this.date,
    required this.steps,
    required this.goalMet,
  });

  Map<String, dynamic> toJson() {
    return {
      'date': date.toIso8601String(),
      'steps': steps,
      'goal_met': goalMet,
    };
  }

  factory DailyStepData.fromJson(Map<String, dynamic> json) {
    return DailyStepData(
      date: DateTime.parse(json['date'] as String),
      steps: json['steps'] as int,
      goalMet: json['goal_met'] as bool,
    );
  }
}

class WeeklyInsight {
  final DateTime weekStart;
  final DateTime weekEnd;
  final int totalSteps;
  final int averageSteps;
  final int daysGoalMet;
  final int totalCaloriesConsumed;
  final int averageCaloriesConsumed;
  final double? weightChange;
  final String trend; // 'improving', 'stable', 'declining'
  final List<String> achievements;
  final List<String> recommendations;
  final DateTime generatedAt;

  WeeklyInsight({
    required this.weekStart,
    required this.weekEnd,
    required this.totalSteps,
    required this.averageSteps,
    required this.daysGoalMet,
    required this.totalCaloriesConsumed,
    required this.averageCaloriesConsumed,
    this.weightChange,
    required this.trend,
    required this.achievements,
    required this.recommendations,
    required this.generatedAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'week_start': weekStart.toIso8601String(),
      'week_end': weekEnd.toIso8601String(),
      'total_steps': totalSteps,
      'average_steps': averageSteps,
      'days_goal_met': daysGoalMet,
      'total_calories_consumed': totalCaloriesConsumed,
      'average_calories_consumed': averageCaloriesConsumed,
      'weight_change': weightChange,
      'trend': trend,
      'achievements': achievements,
      'recommendations': recommendations,
      'generated_at': generatedAt.toIso8601String(),
    };
  }

  factory WeeklyInsight.fromJson(Map<String, dynamic> json) {
    return WeeklyInsight(
      weekStart: DateTime.parse(json['week_start'] as String),
      weekEnd: DateTime.parse(json['week_end'] as String),
      totalSteps: json['total_steps'] as int,
      averageSteps: json['average_steps'] as int,
      daysGoalMet: json['days_goal_met'] as int,
      totalCaloriesConsumed: json['total_calories_consumed'] as int,
      averageCaloriesConsumed: json['average_calories_consumed'] as int,
      weightChange: json['weight_change'] as double?,
      trend: json['trend'] as String,
      achievements: List<String>.from(json['achievements'] as List),
      recommendations: List<String>.from(json['recommendations'] as List),
      generatedAt: DateTime.parse(json['generated_at'] as String),
    );
  }
}

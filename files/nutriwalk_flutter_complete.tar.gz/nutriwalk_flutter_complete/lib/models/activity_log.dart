class ActivityLog {
  final String id;
  final DateTime date;
  final int steps;
  final double? distanceKm;
  final int? activeMinutes;
  final int? caloriesBurned;
  final String source; // 'health_connect', 'health_kit', 'pedometer', 'manual'
  final DateTime createdAt;
  final DateTime updatedAt;

  ActivityLog({
    required this.id,
    required this.date,
    required this.steps,
    this.distanceKm,
    this.activeMinutes,
    this.caloriesBurned,
    required this.source,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'steps': steps,
      'distance_km': distanceKm,
      'active_minutes': activeMinutes,
      'calories_burned': caloriesBurned,
      'source': source,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory ActivityLog.fromJson(Map<String, dynamic> json) {
    return ActivityLog(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      steps: json['steps'] as int,
      distanceKm: json['distance_km'] as double?,
      activeMinutes: json['active_minutes'] as int?,
      caloriesBurned: json['calories_burned'] as int?,
      source: json['source'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  // Calculate estimated distance if not provided
  double get estimatedDistanceKm {
    if (distanceKm != null) return distanceKm!;
    // Average step length is about 0.762 meters
    return (steps * 0.000762);
  }

  // Calculate estimated calories burned if not provided
  int get estimatedCaloriesBurned {
    if (caloriesBurned != null) return caloriesBurned!;
    // Average 0.04 calories per step
    return (steps * 0.04).round();
  }

  // Calculate estimated active minutes
  int get estimatedActiveMinutes {
    if (activeMinutes != null) return activeMinutes!;
    // Average 100 steps per minute
    return (steps / 100).round();
  }

  ActivityLog copyWith({
    String? id,
    DateTime? date,
    int? steps,
    double? distanceKm,
    int? activeMinutes,
    int? caloriesBurned,
    String? source,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return ActivityLog(
      id: id ?? this.id,
      date: date ?? this.date,
      steps: steps ?? this.steps,
      distanceKm: distanceKm ?? this.distanceKm,
      activeMinutes: activeMinutes ?? this.activeMinutes,
      caloriesBurned: caloriesBurned ?? this.caloriesBurned,
      source: source ?? this.source,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class WeightLog {
  final String id;
  final DateTime date;
  final double weightKg;
  final String? notes;
  final DateTime createdAt;

  WeightLog({
    required this.id,
    required this.date,
    required this.weightKg,
    this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'weight_kg': weightKg,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory WeightLog.fromJson(Map<String, dynamic> json) {
    return WeightLog(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      weightKg: (json['weight_kg'] as num).toDouble(),
      notes: json['notes'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }
}

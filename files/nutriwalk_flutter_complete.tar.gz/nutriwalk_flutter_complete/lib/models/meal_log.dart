class MealLog {
  final String id;
  final DateTime timestamp;
  final String mealType; // 'breakfast', 'lunch', 'dinner', 'snack'
  final List<FoodItem> items;
  final String? photoPath;
  final String? notes;
  final int totalCalories;
  final double? totalProteinG;
  final double? totalCarbsG;
  final double? totalFatG;
  final bool isManual;
  final DateTime createdAt;

  MealLog({
    required this.id,
    required this.timestamp,
    required this.mealType,
    required this.items,
    this.photoPath,
    this.notes,
    required this.totalCalories,
    this.totalProteinG,
    this.totalCarbsG,
    this.totalFatG,
    this.isManual = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'meal_type': mealType,
      'items': items.map((item) => item.toJson()).toList(),
      'photo_path': photoPath,
      'notes': notes,
      'total_calories': totalCalories,
      'total_protein_g': totalProteinG,
      'total_carbs_g': totalCarbsG,
      'total_fat_g': totalFatG,
      'is_manual': isManual,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory MealLog.fromJson(Map<String, dynamic> json) {
    return MealLog(
      id: json['id'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      mealType: json['meal_type'] as String,
      items: (json['items'] as List)
          .map((item) => FoodItem.fromJson(item as Map<String, dynamic>))
          .toList(),
      photoPath: json['photo_path'] as String?,
      notes: json['notes'] as String?,
      totalCalories: json['total_calories'] as int,
      totalProteinG: json['total_protein_g'] as double?,
      totalCarbsG: json['total_carbs_g'] as double?,
      totalFatG: json['total_fat_g'] as double?,
      isManual: json['is_manual'] as bool? ?? false,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  String get walkTimeToBalanceFormatted {
    const caloriesPerMinute = 4.0; // Average calories burned per minute of walking
    final minutes = (totalCalories / caloriesPerMinute).round();
    if (minutes < 60) {
      return '$minutes min';
    }
    final hours = minutes ~/ 60;
    final remainingMinutes = minutes % 60;
    return '${hours}h ${remainingMinutes}m';
  }

  int get walkStepsToBalance {
    const caloriesPerStep = 0.04;
    return (totalCalories / caloriesPerStep).round();
  }
}

class FoodItem {
  final String name;
  final double servingSize;
  final String servingUnit;
  final int calories;
  final double? proteinG;
  final double? carbsG;
  final double? fatG;
  final double? fiberG;
  final double? sugarG;

  FoodItem({
    required this.name,
    required this.servingSize,
    required this.servingUnit,
    required this.calories,
    this.proteinG,
    this.carbsG,
    this.fatG,
    this.fiberG,
    this.sugarG,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'serving_size': servingSize,
      'serving_unit': servingUnit,
      'calories': calories,
      'protein_g': proteinG,
      'carbs_g': carbsG,
      'fat_g': fatG,
      'fiber_g': fiberG,
      'sugar_g': sugarG,
    };
  }

  factory FoodItem.fromJson(Map<String, dynamic> json) {
    return FoodItem(
      name: json['name'] as String,
      servingSize: (json['serving_size'] as num).toDouble(),
      servingUnit: json['serving_unit'] as String,
      calories: json['calories'] as int,
      proteinG: json['protein_g'] as double?,
      carbsG: json['carbs_g'] as double?,
      fatG: json['fat_g'] as double?,
      fiberG: json['fiber_g'] as double?,
      sugarG: json['sugar_g'] as double?,
    );
  }

  FoodItem copyWith({
    String? name,
    double? servingSize,
    String? servingUnit,
    int? calories,
    double? proteinG,
    double? carbsG,
    double? fatG,
    double? fiberG,
    double? sugarG,
  }) {
    return FoodItem(
      name: name ?? this.name,
      servingSize: servingSize ?? this.servingSize,
      servingUnit: servingUnit ?? this.servingUnit,
      calories: calories ?? this.calories,
      proteinG: proteinG ?? this.proteinG,
      carbsG: carbsG ?? this.carbsG,
      fatG: fatG ?? this.fatG,
      fiberG: fiberG ?? this.fiberG,
      sugarG: sugarG ?? this.sugarG,
    );
  }
}

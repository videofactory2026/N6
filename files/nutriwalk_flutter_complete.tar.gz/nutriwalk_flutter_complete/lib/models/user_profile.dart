class UserProfile {
  final String id;
  final String name;
  final int age;
  final String gender; // 'male', 'female', 'other'
  final double heightCm;
  final double currentWeightKg;
  final double goalWeightKg;
  final String activityLevel; // 'sedentary', 'lightly_active', 'moderately_active', 'very_active'
  final String goal; // 'lose_weight', 'maintain_weight', 'gain_weight'
  final int dailyStepGoal;
  final int dailyCalorieGoal;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserProfile({
    required this.id,
    required this.name,
    required this.age,
    required this.gender,
    required this.heightCm,
    required this.currentWeightKg,
    required this.goalWeightKg,
    required this.activityLevel,
    required this.goal,
    required this.dailyStepGoal,
    required this.dailyCalorieGoal,
    required this.createdAt,
    required this.updatedAt,
  });

  // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
  double get bmr {
    double bmrValue;
    if (gender == 'male') {
      bmrValue = (10 * currentWeightKg) + (6.25 * heightCm) - (5 * age) + 5;
    } else {
      bmrValue = (10 * currentWeightKg) + (6.25 * heightCm) - (5 * age) - 161;
    }
    return bmrValue;
  }

  // Calculate TDEE (Total Daily Energy Expenditure)
  double get tdee {
    const activityMultipliers = {
      'sedentary': 1.2,
      'lightly_active': 1.375,
      'moderately_active': 1.55,
      'very_active': 1.725,
      'extra_active': 1.9,
    };
    return bmr * (activityMultipliers[activityLevel] ?? 1.2);
  }

  // Calculate BMI
  double get bmi {
    final heightM = heightCm / 100;
    return currentWeightKg / (heightM * heightM);
  }

  String get bmiCategory {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
  }

  // Calculate recommended calorie deficit/surplus based on goal
  int get recommendedCalories {
    switch (goal) {
      case 'lose_weight':
        return (tdee - 500).round(); // 500 cal deficit for ~0.5kg/week loss
      case 'gain_weight':
        return (tdee + 300).round(); // 300 cal surplus
      case 'maintain_weight':
      default:
        return tdee.round();
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'age': age,
      'gender': gender,
      'height_cm': heightCm,
      'current_weight_kg': currentWeightKg,
      'goal_weight_kg': goalWeightKg,
      'activity_level': activityLevel,
      'goal': goal,
      'daily_step_goal': dailyStepGoal,
      'daily_calorie_goal': dailyCalorieGoal,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] as String,
      name: json['name'] as String,
      age: json['age'] as int,
      gender: json['gender'] as String,
      heightCm: (json['height_cm'] as num).toDouble(),
      currentWeightKg: (json['current_weight_kg'] as num).toDouble(),
      goalWeightKg: (json['goal_weight_kg'] as num).toDouble(),
      activityLevel: json['activity_level'] as String,
      goal: json['goal'] as String,
      dailyStepGoal: json['daily_step_goal'] as int,
      dailyCalorieGoal: json['daily_calorie_goal'] as int,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  UserProfile copyWith({
    String? id,
    String? name,
    int? age,
    String? gender,
    double? heightCm,
    double? currentWeightKg,
    double? goalWeightKg,
    String? activityLevel,
    String? goal,
    int? dailyStepGoal,
    int? dailyCalorieGoal,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      heightCm: heightCm ?? this.heightCm,
      currentWeightKg: currentWeightKg ?? this.currentWeightKg,
      goalWeightKg: goalWeightKg ?? this.goalWeightKg,
      activityLevel: activityLevel ?? this.activityLevel,
      goal: goal ?? this.goal,
      dailyStepGoal: dailyStepGoal ?? this.dailyStepGoal,
      dailyCalorieGoal: dailyCalorieGoal ?? this.dailyCalorieGoal,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

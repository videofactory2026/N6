import 'package:flutter/material.dart';

class AppConstants {
  // App Information
  static const String appName = 'NutriWalk AI';
  static const String appVersion = '1.0.0';
  static const String packageName = 'com.nutriwalk.ai';
  
  // Colors
  static const Color primaryColor = Color(0xFF6366F1); // Indigo
  static const Color secondaryColor = Color(0xFF8B5CF6); // Purple
  static const Color backgroundColor = Color(0xFFF8FAFC); // Light Gray
  static const Color cardColor = Colors.white;
  static const Color textDark = Color(0xFF0F172A); // Dark Slate
  static const Color textMedium = Color(0xFF475569); // Slate
  static const Color textLight = Color(0xFF94A3B8); // Light Slate
  
  // Status Colors
  static const Color successColor = Color(0xFF10B981); // Green
  static const Color warningColor = Color(0xFFF59E0B); // Amber
  static const Color errorColor = Color(0xFFEF4444); // Red
  static const Color infoColor = Color(0xFF3B82F6); // Blue
  
  // Spacing
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;
  
  // Border Radius
  static const double radiusSmall = 8.0;
  static const double radiusMedium = 12.0;
  static const double radiusLarge = 16.0;
  static const double radiusXLarge = 24.0;
  
  // Font Sizes
  static const double fontSizeSmall = 12.0;
  static const double fontSizeMedium = 14.0;
  static const double fontSizeLarge = 16.0;
  static const double fontSizeXLarge = 20.0;
  static const double fontSizeHeading = 24.0;
  static const double fontSizeTitle = 32.0;
  
  // Health Constants
  static const int defaultStepGoal = 10000;
  static const int defaultCalorieGoal = 2000;
  static const double caloriesPerStep = 0.04; // Average calories burned per step
  static const double stepsPerMinuteWalking = 100; // Average walking pace
  
  // Nudge Settings
  static const int nudgeHourStart = 20; // 8 PM
  static const int nudgeHourEnd = 21; // 9 PM
  static const int nudgeCheckIntervalMinutes = 30;
  
  // Step Sync Settings
  static const int stepSyncIntervalMinutes = 30;
  
  // Adaptive Learning
  static const int adaptiveLearningWindowDays = 7;
  static const double nudgeIgnoreThreshold = 0.7; // 70% ignore rate triggers tone change
  
  // Database
  static const String databaseName = 'nutriwalk.db';
  static const int databaseVersion = 1;
  
  // Storage Keys
  static const String keyEncryptionKey = 'encryption_key';
  static const String keyUserProfile = 'user_profile';
  static const String keyBehaviorProfile = 'behavior_profile';
  static const String keyOnboardingComplete = 'onboarding_complete';
  
  // API Settings
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost:8787',
  );
  static const String logMealApiKey = String.fromEnvironment('LOGMEAL_API_KEY');
  
  // Notification IDs
  static const int notificationIdNudge = 1;
  static const int notificationIdWeeklyInsight = 2;
  static const int notificationIdGoalReminder = 3;
  
  // Animation Durations
  static const Duration animationFast = Duration(milliseconds: 150);
  static const Duration animationMedium = Duration(milliseconds: 300);
  static const Duration animationSlow = Duration(milliseconds: 500);
  
  // BMI Categories
  static const double bmiUnderweight = 18.5;
  static const double bmiNormal = 24.9;
  static const double bmiOverweight = 29.9;
  
  // Activity Levels
  static const Map<String, double> activityMultipliers = {
    'sedentary': 1.2,
    'lightly_active': 1.375,
    'moderately_active': 1.55,
    'very_active': 1.725,
    'extra_active': 1.9,
  };
}
